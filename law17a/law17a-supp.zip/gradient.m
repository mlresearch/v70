clear all;

n = 10;
d = 4;
rank_of_C = 7;

Y = rand(n,rank_of_C)*10;
C = Y * pinv(Y);

F = (rand(n,d)*10) - 5;
Real_gradient = 2*(eye(n) - F*pinv(F)) * C * pinv(F)';
epsilon = 10^-7;

Approximate_gradient = zeros(n,d);

for i=1:n
  for j=1:d
    E = zeros(n,d);
    E(i,j) = epsilon;

    X1 = F+E;
    X2 = F-E;

    Approximate_gradient(i,j) = (trace(X1 * pinv(X1) * C) - trace(X2 * pinv(X2) * C))/(2*epsilon);
  end
end


Real_gradient
Approximate_gradient

disp('Frobenius distance')
norm(Real_gradient-Approximate_gradient,'fro')
