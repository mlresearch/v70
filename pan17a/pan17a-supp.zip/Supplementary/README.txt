There are two files in this supplementary material
(1) Experimental video for high-speed autonomous rally car driving, which is used to demonstrate our proposed Bayesian filtering algorithms. This video was recorded under a continuous drive for 30 seconds.
(2) A single pdf document contains necessary definitions and derivations that are omitted in the main paper due to space limit. Additional experimental results, control task descriptions, and further discussions are also covered in this document.
