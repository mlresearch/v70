We use some functions from the lightspeed library by Tom Minka.
