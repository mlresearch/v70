"""Groups of problems of different types for optimizer training."""

from collections import namedtuple
import numpy as np
import tensorflow as tf

import datasets
import problem_generator as pg

quadratic_problems = [
    (Spec(pg.Quadratic, (20,), {}), None, None),
    (Spec(pg.Quadratic, (25,), {}), None, None),
    (Spec(pg.Quadratic, (50,), {}), None, None),
    (Spec(pg.Quadratic, (100,), {}), None, None),
]

# Note: this group contains one non-noisy problem for historical reasons. The
# original training set before the refactor included this set of quadratics.
quadratic_problems_noisy = [
    (Spec(pg.Quadratic, (20,), {"noise_stdev": 0.5}), None, None),
    (Spec(pg.Quadratic, (25,), {"noise_stdev": 0.0}), None, None),
    (Spec(pg.Quadratic, (50,), {"noise_stdev": 1.0}), None, None),
    (Spec(pg.Quadratic, (100,), {"noise_stdev": 2.0}), None, None),
]

quadratic_problems_large = [
    (Spec(pg.Quadratic, (784,), {}), None, None),
    (Spec(pg.Quadratic, (1024,), {}), None, None),
    (Spec(pg.Quadratic, (2048,), {}), None, None),
]

bowl_problems = [
    (Spec(pg.Bowl, (0.1,), {"noise_stdev": 0.0}), None, None),
    (Spec(pg.Bowl, (1.0,), {"noise_stdev": 0.0}), None, None),
    (Spec(pg.Bowl, (5.0,), {"noise_stdev": 0.0}), None, None),
    (Spec(pg.Bowl, (5.0,), {"noise_stdev": 0.0, "angle": np.pi / 4.}),
     None, None),
]

bowl_problems_noisy = [
    (Spec(pg.Bowl, (0.1,), {"noise_stdev": 0.1}), None, None),
    (Spec(pg.Bowl, (1.0,), {"noise_stdev": 0.1}), None, None),
    (Spec(pg.Bowl, (5.0,), {"noise_stdev": 0.1}), None, None),
    (Spec(pg.Bowl, (5.0,), {"noise_stdev": 0.1, "angle": np.pi / 4.}),
     None, None),
]

softmax_2_class_problems = [
    (Spec(pg.SoftmaxRegression, (10, 2), {}),
     datasets.random(10, 1000, random_seed=123, sep=2.0), 100),
    (Spec(pg.SoftmaxRegression, (100, 2), {}),
     datasets.random(100, 1000, random_seed=123), 50),
    (Spec(pg.SoftmaxRegression, (200, 2), {}),
     datasets.random(200, 1000, random_seed=123, sep=1.5), 20),
    (Spec(pg.SoftmaxRegression, (256, 2), {}),
     datasets.random(256, 1000, random_seed=123, sep=1.5), 100),
]

softmax_2_class_problems_noisy = [
    (Spec(pg.SoftmaxRegression, (10, 2), {"noise_stdev": 0.5}),
     datasets.random(10, 1000, random_seed=123, sep=2.0), 100),
    (Spec(pg.SoftmaxRegression, (100, 2), {"noise_stdev": 0.1}),
     datasets.random(100, 1000, random_seed=123), 50),
    (Spec(pg.SoftmaxRegression, (200, 2), {"noise_stdev": 0.1}),
     datasets.random(200, 1000, random_seed=123, sep=1.5), 20),
    (Spec(pg.SoftmaxRegression, (256, 2), {"noise_stdev": 0.5}),
     datasets.random(256, 1000, random_seed=123, sep=1.5), 100),
]

optimization_test_problems = [
    (Spec(pg.Ackley, (), {}), None, None),
    (Spec(pg.Beale, (), {}), None, None),
    (Spec(pg.Booth, (), {}), None, None),
    (Spec(pg.Branin, (), {}), None, None),
    (Spec(pg.LogSumExp, (), {}), None, None),
    (Spec(pg.Matyas, (), {}), None, None),
    (Spec(pg.Michalewicz, (), {}), None, None),
    (Spec(pg.Rosenbrock, (), {}), None, None),
    (Spec(pg.StyblinskiTang, (), {}), None, None),
]

optimization_test_problems_noisy = [
    (Spec(pg.Ackley, (), {"noise_stdev": 1.}), None, None),
    (Spec(pg.Beale, (), {"noise_stdev": 1.}), None, None),
    (Spec(pg.Booth, (), {"noise_stdev": 1.}), None, None),
    (Spec(pg.Branin, (), {"noise_stdev": 1.}), None, None),
    (Spec(pg.LogSumExp, (), {"noise_stdev": 1.}), None, None),
    (Spec(pg.Matyas, (), {"noise_stdev": 1.}), None, None),
    (Spec(pg.Michalewicz, (), {"noise_stdev": 1.}), None, None),
    (Spec(pg.Rosenbrock, (), {"noise_stdev": 1.}), None, None),
    (Spec(pg.StyblinskiTang, (), {"noise_stdev": 1.}), None, None),
]

log_objective_problems = [
    (Spec(pg.LogObjective, [Spec(pg.Quadratic, (20,), {})], {}), None, None),
    (Spec(pg.LogObjective, [Spec(pg.Quadratic, (50,), {})], {}), None, None),
    (Spec(pg.LogObjective, [Spec(pg.Quadratic, (100,), {})], {}), None, None),
    (Spec(pg.LogObjective, [Spec(pg.Bowl, (0.1,), {})], {}), None, None),
    (Spec(pg.LogObjective, [Spec(pg.Bowl, (1.0,), {})], {}), None, None),
    (Spec(pg.LogObjective, [Spec(pg.Bowl, (5.0,), {})], {}), None, None),
]

sparse_gradient_problems = [
    (Spec(pg.SparseProblem, [Spec(pg.Quadratic, (20,), {})], {}),
     None, None),
    (Spec(pg.SparseProblem, [Spec(pg.Quadratic, (50,), {})], {}),
     None, None),
    (Spec(pg.SparseProblem, [Spec(pg.Quadratic, (100,), {})], {}),
     None, None),
    (Spec(pg.SparseProblem, [Spec(pg.Bowl, (0.1,), {})], {}),
     None, None),
    (Spec(pg.SparseProblem, [Spec(pg.Bowl, (1.0,), {})], {}),
     None, None),
    (Spec(pg.SparseProblem, [Spec(pg.Bowl, (5.0,), {})], {}),
     None, None),
]

rescale_problems = [
    (Spec(pg.Rescale, [Spec(pg.Norm, (18,), {"norm_power": 2.5})],
          {"scale": 0.123}), None, None),
    (Spec(pg.Rescale, [Spec(pg.Norm, (18,), {"norm_power": 1.5})],
          {"scale": 8}), None, None),
    (Spec(pg.Rescale, [Spec(pg.Norm, (18,), {"norm_power": 2.})],
          {"scale": 50}), None, None),
    (Spec(pg.Rescale, [Spec(pg.Norm, (18,), {"norm_power": 3.})],
          {"scale": 200}), None, None),
    (Spec(pg.Rescale, [Spec(pg.Norm, (18,), {"norm_power": 1.})],
          {"scale": 1000}), None, None),
    (Spec(pg.Rescale, [Spec(pg.Quadratic, (20,), {})], {"scale": 0.1}),
     None, None),
    (Spec(pg.Rescale, [Spec(pg.Quadratic, (25,), {})], {"scale": 10.}),
     None, None),
    (Spec(pg.Rescale, [Spec(pg.Quadratic, (50,), {})], {"scale": 350.}),
     None, None),
    (Spec(pg.Rescale, [Spec(pg.Quadratic, (100,), {})], {"scale": 132}),
     None, None),
]

norm_problems = [
    # 0.5 Norm causes NaN gradients early in training
    # (Spec(pg.Norm, (18,), {"norm_power": 0.5}), None, None),
    (Spec(pg.Norm, (27,), {"norm_power": 1.}), None, None),
    (Spec(pg.Norm, (25,), {"norm_power": 2.}), None, None),
    (Spec(pg.Norm, (22,), {"norm_power": 3.}), None, None),
]

norm_problems_noisy = [
    # 0.5 Norm causes NaN gradients early in training
    # (Spec(pg.Norm, (31,), {"noise_stdev": .1, "norm_power": .5}), None, None),
    (Spec(pg.Norm, (19,), {"noise_stdev": .1, "norm_power": 1.}), None, None),
    (Spec(pg.Norm, (26,), {"noise_stdev": .1, "norm_power": 2.}), None, None),
    (Spec(pg.Norm, (23,), {"noise_stdev": .1, "norm_power": 3.}), None, None),
]

sum_problems = [
    (Spec(pg.SumTask, [[
        Spec(pg.Quadratic, (11,), {}),
        Spec(pg.Quadratic, (3,), {}),
        Spec(pg.Quadratic, (9,), {}),
        Spec(pg.Quadratic, (7,), {}),
        Spec(pg.Quadratic, (5,), {}),
        Spec(pg.Quadratic, (13,), {}),
        Spec(pg.Quadratic, (12,), {})]], {}), None, None),
    (Spec(pg.SumTask, [[
        Spec(pg.Norm, (18,), {"norm_power": 3}),
        Spec(pg.Quadratic, (25,), {}),
        Spec(pg.Rosenbrock, (), {})]], {}), None, None),
    (Spec(pg.SumTask, [[
        Spec(pg.Rosenbrock, (), {}),
        Spec(pg.LogSumExp, (), {}),
        Spec(pg.Ackley, (), {}),
        Spec(pg.Beale, (), {}),
        Spec(pg.Booth, (), {}),
        Spec(pg.StyblinskiTang, (), {}),
        Spec(pg.Matyas, (), {}),
        Spec(pg.Branin, (), {}),
        Spec(pg.Michalewicz, (), {})]], {}), None, None),
    (Spec(pg.SumTask, [[
        Spec(pg.Rosenbrock, (), {}),
        Spec(pg.LogSumExp, (), {}),
        Spec(pg.Ackley, (), {}),
        Spec(pg.Beale, (), {}),
        Spec(pg.Booth, (), {}),
        Spec(pg.StyblinskiTang, (), {}),
        Spec(pg.Matyas, (), {}),
        Spec(pg.Branin, (), {}),
        Spec(pg.Michalewicz, (), {}),
        Spec(pg.Quadratic, (5,), {}),
        Spec(pg.Quadratic, (13,), {})]], {}), None, None),
]

sum_problems_noisy = [
    (Spec(pg.SumTask, [[
        Spec(pg.Quadratic, (11,), {"noise_stdev": 0.1}),
        Spec(pg.Quadratic, (3,), {"noise_stdev": 0.1}),
        Spec(pg.Quadratic, (9,), {"noise_stdev": 0.1}),
        Spec(pg.Quadratic, (7,), {"noise_stdev": 0.1}),
        Spec(pg.Quadratic, (5,), {"noise_stdev": 0.1}),
        Spec(pg.Quadratic, (13,), {"noise_stdev": 0.1}),
        Spec(pg.Quadratic, (12,), {"noise_stdev": 0.1})]], {}), None, None),
    (Spec(pg.SumTask, [[
        Spec(pg.Rosenbrock, (), {}),
        Spec(pg.LogSumExp, (), {}),
        Spec(pg.Ackley, (), {}),
        Spec(pg.Beale, (), {}),
        Spec(pg.Booth, (), {}),
        Spec(pg.StyblinskiTang, (), {}),
        Spec(pg.Matyas, (), {}),
        Spec(pg.Branin, (), {}),
        Spec(pg.Michalewicz, (), {}),
        Spec(pg.Quadratic, (5,), {}),
        Spec(pg.Quadratic, (13,), {"noise_stdev": 0.5})]], {}), None, None),
]

dependency_chain_problems = [
    (Spec(pg.DependencyChain, (20,), {}),
     datasets.random_binary(20, 1000), 100),
    (Spec(pg.DependencyChain, (12,), {}),
     datasets.random_binary(12, 200), 10),
    (Spec(pg.DependencyChain, (56,), {}),
     datasets.random_binary(56, 5000), 100),
    (Spec(pg.DependencyChain, (64,), {}),
     datasets.random_binary(64, 1000), 50),
    (Spec(pg.DependencyChain, (13,), {}),
     datasets.random_binary(13, 10000), 50),
    (Spec(pg.DependencyChain, (20,), {}),
     datasets.random_binary(20, 1000), 128),
    (Spec(pg.DependencyChain, (12,), {}),
     datasets.random_binary(12, 300), 16),
    (Spec(pg.DependencyChain, (56,), {}),
     datasets.random_binary(56, 5000), 128),
    (Spec(pg.DependencyChain, (64,), {}),
     datasets.random_binary(64, 1000), 64),
    (Spec(pg.DependencyChain, (13,), {}),
     datasets.random_binary(13, 10000), 32),
]

outward_snake_problems = [
    (Spec(pg.OutwardSnake, (20,), {}),
     datasets.random_binary(20, 1000), 100),
    (Spec(pg.OutwardSnake, (12,), {}),
     datasets.random_binary(12, 200), 10),
    (Spec(pg.OutwardSnake, (56,), {}),
     datasets.random_binary(56, 5000), 100),
    (Spec(pg.OutwardSnake, (64,), {}),
     datasets.random_binary(64, 1000), 50),
    (Spec(pg.OutwardSnake, (13,), {}),
     datasets.random_binary(13, 10000), 50),
    (Spec(pg.OutwardSnake, (20,), {}),
     datasets.random_binary(20, 1000), 128),
    (Spec(pg.OutwardSnake, (12,), {}),
     datasets.random_binary(12, 300), 16),
    (Spec(pg.OutwardSnake, (56,), {}),
     datasets.random_binary(56, 5000), 128),
    (Spec(pg.OutwardSnake, (64,), {}),
     datasets.random_binary(64, 1000), 64),
    (Spec(pg.OutwardSnake, (13,), {}),
     datasets.random_binary(13, 10000), 32),
]

min_max_well_problems = [
    (Spec(pg.MinMaxWell, (20,), {}), None, None),
    (Spec(pg.MinMaxWell, (12,), {}), None, None),
    (Spec(pg.MinMaxWell, (56,), {}), None, None),
    (Spec(pg.MinMaxWell, (64,), {}), None, None),
    (Spec(pg.MinMaxWell, (13,), {}), None, None),
]

projection_quadratic_problems = [
    (Spec(pg.ProjectionQuadratic, (20,), {}),
     datasets.random_symmetric(20, 1000), 100),
    (Spec(pg.ProjectionQuadratic, (12,), {}),
     datasets.random_symmetric(12, 100), 10),
    (Spec(pg.ProjectionQuadratic, (56,), {}),
     datasets.random_symmetric(56, 5000), 100),
    (Spec(pg.ProjectionQuadratic, (64,), {}),
     datasets.random_symmetric(64, 1000), 50),
    (Spec(pg.ProjectionQuadratic, (13,), {}),
     datasets.random_symmetric(13, 10000), 50),
    (Spec(pg.ProjectionQuadratic, (20,), {}),
     datasets.random_symmetric(20, 1000), 128),
    (Spec(pg.ProjectionQuadratic, (12,), {}),
     datasets.random_symmetric(12, 100), 16),
    (Spec(pg.ProjectionQuadratic, (56,), {}),
     datasets.random_symmetric(56, 5000), 128),
    (Spec(pg.ProjectionQuadratic, (64,), {}),
     datasets.random_symmetric(64, 1000), 64),
    (Spec(pg.ProjectionQuadratic, (13,), {}),
     datasets.random_symmetric(13, 10000), 32),
]


class Spec(namedtuple("Spec", "callable args kwargs")):
  """Syntactic sugar for keeping track of a function/class + args."""

  # since this is an immutable object, we don't need to reserve slots
  __slots__ = ()

  def build(self):
    """Returns the output of the callable."""
    return self.callable(*self.args, **self.kwargs)
